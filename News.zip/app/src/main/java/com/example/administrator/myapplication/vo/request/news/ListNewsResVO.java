package com.example.administrator.myapplication.vo.request.news;

/**
 * Created by Administrator on 2017/11/25 0025.
 */

public class ListNewsResVO {
    private String type;
    private String key;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
