package com.example.administrator.myapplication.config;

/**
 * Created by Administrator on 2017/11/25 0025.
 */

public class ApiConfig {
    public static final String BASE_URL = "http://v.juhe.cn";
}
